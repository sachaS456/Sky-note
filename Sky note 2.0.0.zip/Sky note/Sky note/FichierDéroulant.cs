﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_note
{
    internal delegate void EventButtonClickHandler();

    internal partial class FichierDéroulant : UserControl
    {
        internal event EventButtonClickHandler OpenFile = null;
        internal event EventButtonClickHandler SaveAsFile = null;
        internal event EventButtonClickHandler SaveFile = null;
        internal event EventButtonClickHandler NewFile = null;
        internal event EventButtonClickHandler NewWindow = null;

        internal FichierDéroulant()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // ouvrir
            ExecuterEvenementOpenFile();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // enregistrer sous
            ExecuterEvenementSaveAsFile();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // enregistrer
            ExecuterEvenementSaveFile();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // nouveau
            ExecuterEvenementNewFile();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // nouvelle fenêtre
            ExecuterEvenementNewWindow();
        }

        protected virtual void ExecuterEvenementOpenFile()
        {
            if (OpenFile != null)
            {
                OpenFile();
            }
        }

        protected virtual void ExecuterEvenementSaveAsFile()
        {
            if (SaveAsFile != null)
            {
                SaveAsFile();
            }
        }

        protected virtual void ExecuterEvenementSaveFile()
        {
            if (SaveFile != null)
            {
                SaveFile();
            }
        }

        protected virtual void ExecuterEvenementNewFile()
        {
            if (NewFile != null)
            {
                NewFile();
            }
        }

        protected virtual void ExecuterEvenementNewWindow()
        {
            if (NewWindow != null)
            {
                NewWindow();
            }
        }
    }
}
