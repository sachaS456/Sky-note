﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace Sky_note
{
    internal partial class FormPrincipal : Form
    {
        private bool FormCache = false;
        private int Coter = 0;
        private bool FormDeplace = false;
        private int LocX = 0;
        private int LocY = 0;
        private const int MiniLargeForm = 443;
        private const int MiniHautForm = 298;
        private FichierDéroulant FichierDéroulant1 = new FichierDéroulant();
        private EncodageDeroulant EncodageDéroulant1 = new EncodageDeroulant();
        private bool FichierDéroulant1Hide = true;
        private string FileLoaded = string.Empty;
        private bool NoChiffre = false;
        private bool EncodageDéroulant1Hide = false;
        private Encoding EncodingUsed = Encoding.UTF8;

        internal FormPrincipal()
        {
            InitializeComponent();

            this.Opacity = 0;
            timer1.Enabled = true;

            FichierDéroulant1.Location = new Point(0, -136);
            FichierDéroulant1.Visible = false;
            FichierDéroulant1.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            FichierDéroulant1.BringToFront();
            this.panel1.Controls.Add(FichierDéroulant1);
            FichierDéroulant1.Parent = textBox1;
            FichierDéroulant1.Cursor = Cursors.Default;
            FichierDéroulant1.OpenFile += new EventButtonClickHandler(OpenFile);
            FichierDéroulant1.SaveAsFile += new EventButtonClickHandler(SaveAsFile);
            FichierDéroulant1.SaveFile += new EventButtonClickHandler(SaveFile);
            FichierDéroulant1.NewFile += new EventButtonClickHandler(NewFile);
            FichierDéroulant1.NewWindow += new EventButtonClickHandler(NewWindow);

            EncodageDéroulant1.Location = new Point(545, -136);
            EncodageDéroulant1.Visible = false;
            EncodageDéroulant1.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            EncodageDéroulant1.BringToFront();
            this.panel1.Controls.Add(EncodageDéroulant1);
            EncodageDéroulant1.Parent = textBox1;
            EncodageDéroulant1.Cursor = Cursors.Default;
            EncodageDéroulant1.EventEncoding += new EventEncodingHandler(this.EncodageDéroulant1_EventEncoding);
        }

        #region FormConfig
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // animation de form arrêt ou démarre
            if (FormCache == false)
            {
                if (Opacity <= 0.99)
                {
                    Opacity += 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    FormCache = true;
                }
            }
            else
            {
                if (Opacity >= 0.01)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    timer1.Enabled = false;
                    Environment.Exit(0);
                }
            }
        }

        private void FormPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Enabled = true;
            e.Cancel = true;
        }

        private void FormPrincipal_MouseDown(object sender, MouseEventArgs e)
        {
            // déplacement active car souris préssée
            if (e.Button == MouseButtons.Left && this.Cursor == Cursors.Default)
            {
                LocX = e.X;
                LocY = e.Y;

                FormDeplace = true;
                return;
            }

            if (this.Cursor != Cursors.Default)
            {
                /// Coin :

                if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas droite
                    Coter = 8;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y >= this.Size.Height - 2)
                {
                    // agrandit ou réduit coin bas gauche
                    Coter = 7;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X >= this.Size.Width - 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut droite
                    Coter = 5;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X <= 2 && e.Y <= 2)
                {
                    // agrandit ou réduit coin haut gauche
                    Coter = 6;
                    timer2.Enabled = true;
                    return;
                }

                /// cotée :

                if (e.X == 0)
                {
                    // agrandit ou réduit coté gauche

                    Coter = 2;
                    timer2.Enabled = true;
                    return;
                }

                if (e.X == this.Size.Width - 1)
                {
                    // agrandit ou réduit coté droite

                    Coter = 1;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == this.Size.Height - 1)
                {
                    // agrandit ou réduit coté bas
                    Coter = 4;
                    timer2.Enabled = true;
                    return;
                }

                if (e.Y == 0)
                {
                    // agrandit ou réduit coté haut
                    Coter = 3;
                    timer2.Enabled = true;
                    return;
                }
            }
        }

        private void FormPrincipal_MouseUp(object sender, MouseEventArgs e)
        {
            timer2.Enabled = false;
            Coter = 0;
            FormDeplace = false;
        }

        private void FormPrincipal_MouseMove(object sender, MouseEventArgs e)
        {
            // déplacement de la fenêtre
            if (FormDeplace == true)
            {
                this.Location = new Point(MousePosition.X - LocX, MousePosition.Y - LocY);
            }

            this.Cursor = Cursors.Default;
            button2.Cursor = Cursors.Default;

            if (e.X >= this.Size.Width - 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas droite
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X <= 2 && e.Y >= this.Size.Height - 2)
            {
                // agrandit ou réduit coin bas gauche
                this.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X <= 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut gauche
                this.Cursor = Cursors.SizeNWSE;
                return;
            }

            if (e.X == this.Size.Width - 1)
            {
                // agrandit ou réduit coté droite
                this.Cursor = Cursors.SizeWE;
                button2.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.X == 0)
            {
                // agrandit ou réduit coté gauche
                this.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == this.Size.Height - 1)
            {
                // agrandit ou réduit coté bas
                this.Cursor = Cursors.SizeNS;
                return;
            }

            if (e.Y == 0)
            {
                // agrandit ou réduit coté haut
                this.Cursor = Cursors.SizeNS;
                button2.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            switch (Coter)
            {
                case 1:  // côtée droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 2: // côtée gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height);
                    }
                    break;

                case 3:  // côtée haut
                    if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 4:  // côtée bas
                    if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(this.Size.Width, MiniHautForm);
                    }
                    break;

                case 5:  // coin haut droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 6:  // coin haut gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(MousePosition.X, MousePosition.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Height - (MousePosition.Y - this.Location.Y) >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, this.Size.Height - (MousePosition.Y - this.Location.Y));
                        this.Location = new Point(this.Location.X, MousePosition.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 7:  // coin bas gauche
                    if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MousePosition.Y - this.Location.Y);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (this.Size.Width - (MousePosition.X - this.Location.X) >= MiniLargeForm)
                    {
                        this.Size = new Size(this.Size.Width - (MousePosition.X - this.Location.X), MiniHautForm);
                        this.Location = new Point(MousePosition.X, this.Location.Y);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;

                case 8:  // coin bas droit
                    if (MousePosition.X - this.Location.X >= MiniLargeForm && MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MousePosition.Y - this.Location.Y);
                    }
                    else if (MousePosition.X - this.Location.X >= MiniLargeForm)
                    {
                        this.Size = new Size(MousePosition.X - this.Location.X, MiniHautForm);
                    }
                    else if (MousePosition.Y - this.Location.Y >= MiniHautForm)
                    {
                        this.Size = new Size(MiniLargeForm, MousePosition.Y - this.Location.Y);
                    }
                    else
                    {
                        this.Size = new Size(MiniLargeForm, MiniHautForm);
                    }
                    break;
            }
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            button2.Cursor = Cursors.Default;


            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                button1.Cursor = Cursors.SizeNESW;
                return;
            }

            if (e.X == button1.Size.Width - 1)
            {
                // droite
                button1.Cursor = Cursors.SizeWE;
                return;
            }

            if (e.Y == 1)
            {
                // haut
                button1.Cursor = Cursors.SizeNS;
                return;
            }
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.X >= button1.Size.Width - 2 && e.Y <= 2)
            {
                // agrandit ou réduit coin haut droite
                Coter = 5;
                timer2.Enabled = true;
                return;
            }

            if (e.X == button1.Size.Width - 2)
            {
                // agrandit ou réduit coté droite

                Coter = 1;
                timer2.Enabled = true;
                return;
            }

            if (e.Y == 1)
            {
                // agrandit ou réduit coté haut
                Coter = 3;
                timer2.Enabled = true;
                return;
            }
        }
        #endregion

        private void button6_Click(object sender, EventArgs e)
        {
            // button Quitter
            timer1.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // button À propos
            new InfoApp().ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // button Fichier
            timer3.Enabled = true;
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (FichierDéroulant1Hide == true) // si FichierDéroulant1 cacher
            {
                // montrer
                FichierDéroulant1.Visible = true;
                FichierDéroulant1.Location = new Point(FichierDéroulant1.Location.X, FichierDéroulant1.Location.Y + 15);

                if (FichierDéroulant1.Location.Y >= 1)
                {
                    timer3.Enabled = false;
                    FichierDéroulant1Hide = false;
                    FichierDéroulant1.Location = new Point(0, 1);
                    textBox1.Cursor = Cursors.Default;
                }
            }
            else  // si FichierDéroulant1 montrer
            {
                // cacher
                FichierDéroulant1.Location = new Point(FichierDéroulant1.Location.X, FichierDéroulant1.Location.Y - 15);

                if (FichierDéroulant1.Location.Y <= -136)
                {
                    timer3.Enabled = false;
                    FichierDéroulant1.Visible = false;
                    FichierDéroulant1Hide = true;
                    FichierDéroulant1.Location = new Point(0, -136);
                    textBox1.Cursor = Cursors.IBeam;
                }
            }
        }

        private void OpenFile()
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "Tous les fichiers| *.*";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    FileRead(dialog.FileName);
                }
                dialog.Dispose();
            }
        }

        private Encoding EncodeAdapt(string FileName)
        {
            byte[] bytes = File.ReadAllBytes(FileName);
            string text = null;

            if (Encoding.UTF8.TryGetString(bytes, out text))
            {
                return Encoding.UTF8;
            }
            else if (Encoding.ASCII.TryGetString(bytes, out text))
            {
                return Encoding.ASCII;
            }
            else if (Encoding.Latin1.TryGetString(bytes, out text))
            {
                return Encoding.Latin1;
            }
            else if (Encoding.UTF32.TryGetString(bytes, out text))
            {
                return Encoding.UTF32;
            }
            else if (Encoding.BigEndianUnicode.TryGetString(bytes, out text))
            {
                return Encoding.BigEndianUnicode;
            }
            else if (Encoding.Unicode.TryGetString(bytes, out text))
            {
                return Encoding.Unicode;
            }
#pragma warning disable
            else if (Encoding.UTF7.TryGetString(bytes, out text))
            {
                if (MessageBox.Show("Attention cet encodage n'est plus pris en charge. Pour votre sécurité il n'est pas recommandé de lire ce fichier! Voulez vous quand même le lire?", "Sky note",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    return Encoding.UTF7;
#warning
                }
                else
                {
                    return null;
                }
            }
            else
            {
                MessageBox.Show("Ce fichier est n'est pas pris en charge!", "Sky note", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }        

        private void SaveAsFile()
        {
            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Filter = "Fichier texte| *.txt";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter WriteText = new StreamWriter(new FileStream(dialog.FileName, FileMode.CreateNew), EncodingUsed))
                    {
                        WriteText.Write(textBox1.Text, EncodingUsed);
                        FileLoaded = dialog.FileName;
                        WriteText.Close();
                    }
                }
                dialog.Dispose();
            }
        }

        private void SaveFile()
        {
            if (FileLoaded == string.Empty)
            {
                SaveAsFile();
            }
            else
            {
                using (StreamWriter WriteText = new StreamWriter(new FileStream(FileLoaded, FileMode.Create), EncodingUsed))
                {
                    WriteText.Write(textBox1.Text, EncodingUsed);
                    WriteText.Close();
                }
            }
        }

        private void NewFile()
        {
            if (FileLoaded != string.Empty || textBox1.Text != string.Empty)
            {
                switch (MessageBox.Show("Voulez vous sauvegarder votre travail?", "Sky picture", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question))
                {
                    case DialogResult.Yes:
                        SaveFile();
                        break;

                    case DialogResult.Cancel:
                        return;
                }
            }

            textBox1.Text = string.Empty;
            FileLoaded = string.Empty;
        }

        private void NewWindow()
        {
            Process process = new Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = Application.ExecutablePath;
            process.Start();
            process.Close();
            process = null;
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (FichierDéroulant1Hide == false)
            {
                timer3.Enabled = true;
            }

            if (EncodageDéroulant1Hide == false)
            {
                timer5.Enabled = true;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (FichierDéroulant1Hide == false)
            {
                timer3.Enabled = true;
            }

            if (EncodageDéroulant1Hide == false)
            {
                timer5.Enabled = true;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Select();
            if (textBox1.SelectionLength > 0)
            {
                textBox1.DeselectAll();
                button7.Text = "Tout désélectionner";
            }
            else
            {
                textBox1.SelectAll();
                button7.Text = "Tout sélectionner";
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            if (textBox1.SelectionLength > 0)
            {
                button7.Text = "Tout désélectionner";
            }
            else
            {
                button7.Text = "Tout sélectionner";
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (textBox2.Text != string.Empty)
                {
                    GoLine(Convert.ToInt64(textBox2.Text));
                    textBox2.Text = string.Empty;
                }
                return;
            }

            if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 || e.KeyCode == Keys.D5 ||
                e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9)
            {
                switch (e.KeyCode)
                {
                    case Keys.D0:
                        textBox2.Text += "0";
                        break;

                    case Keys.D1:
                        textBox2.Text += "1";
                        break;

                    case Keys.D2:
                        textBox2.Text += "2";
                        break;

                    case Keys.D3:
                        textBox2.Text += "3";
                        break;

                    case Keys.D4:
                        textBox2.Text += "4";
                        break;

                    case Keys.D5:
                        textBox2.Text += "5";
                        break;

                    case Keys.D6:
                        textBox2.Text += "6";
                        break;

                    case Keys.D7:
                        textBox2.Text += "7";
                        break;

                    case Keys.D8:
                        textBox2.Text += "8";
                        break;

                    case Keys.D9:
                        textBox2.Text += "9";
                        break;
                }
                textBox2.Select(textBox2.Text.Length, 0);
                NoChiffre = true;
                return;
            }

            if (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.NumPad4 ||
                e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.NumPad9 || e.KeyCode == Keys.Back)
            {
                NoChiffre = false;
            }
            else
            {
                NoChiffre = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = NoChiffre;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != string.Empty)
            {
                GoLine(Convert.ToInt64(textBox2.Text));
                textBox2.Text = string.Empty;
            }
        }

        private void GoLine(long line)
        {
            textBox1.Select();
            if (textBox1.Text != string.Empty && textBox2.Text != string.Empty)
            {
                int seed = 0, pos = -1;

                line -= 1;

                if (line == 0)
                {
                    pos = 0;
                }
                else
                {
                    for (long i = 0; i < line; i++)
                    {
                        pos = textBox1.Text.IndexOf(Environment.NewLine, seed) + 2;
                        seed = pos;
                    }
                }

                if (pos != -1)
                {
                    textBox1.Select(pos, 0);
                }
                textBox1.ScrollToCaret();
                textBox1.Refresh();
            }
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            if (Environment.GetCommandLineArgs().Last() != Application.ExecutablePath && Environment.GetCommandLineArgs().Last() != Application.StartupPath + "Sky note.dll")
            {
                try
                {
                    FileRead(Environment.GetCommandLineArgs().Last());
                    FileLoaded = Environment.GetCommandLineArgs().Last();
                }
                catch
                {
                    MessageBox.Show("Une erreur est survenue!", "Sky note", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            timer5.Enabled = true;
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (EncodageDéroulant1Hide == true) // si EncodageDéroulant1 cacher
            {
                // montrer
                EncodageDéroulant1.Visible = true;
                EncodageDéroulant1.Location = new Point(EncodageDéroulant1.Location.X, EncodageDéroulant1.Location.Y + 15);

                if (EncodageDéroulant1.Location.Y >= 1)
                {
                    timer5.Enabled = false;
                    EncodageDéroulant1Hide = false;
                    EncodageDéroulant1.Location = new Point(545, 1);
                    textBox1.Cursor = Cursors.Default;
                }
            }
            else  // si EncodageDéroulant1 montrer
            {
                // cacher
                EncodageDéroulant1.Location = new Point(EncodageDéroulant1.Location.X, EncodageDéroulant1.Location.Y - 15);

                if (EncodageDéroulant1.Location.Y <= -136)
                {
                    timer5.Enabled = false;
                    EncodageDéroulant1.Visible = false;
                    EncodageDéroulant1Hide = true;
                    EncodageDéroulant1.Location = new Point(545, -136);
                    textBox1.Cursor = Cursors.IBeam;
                }
            }
        }

        private void EncodageDéroulant1_EventEncoding(ref Encoding e)
        {
            button9.Text = e.BodyName;
            //FileRead(FileLoaded, e);
            //string convert = e.GetString(EncodingUsed.GetBytes(textBox1.Text));
            //textBox1.Text = convert;
            EncodingUsed = e;
        }

        private void FileRead(string FileName, Encoding en = null)
        {
            if (en != null)
            {
                using (StreamReader readText = new StreamReader(FileName, en))
                {
                    textBox1.Text = readText.ReadToEnd();
                    readText.Close();
                    button9.Text = en.BodyName;
                    FileLoaded = FileName;
                }
            }
            else
            {
                using (StreamReader readText = new StreamReader(FileName, EncodeAdapt(FileName)))
                {
                    textBox1.Text = readText.ReadToEnd();
                    readText.Close();
                    button9.Text = readText.CurrentEncoding.BodyName;
                    FileLoaded = FileName;
                }
            }
        }
    }

    internal static class Extensions
    {
        internal static bool TryGetString(this Encoding encoding, byte[] bytes, out string result)
        {
            return encoding.TryGetString(bytes, 0, bytes.Length, out result);
        }

        internal static bool TryGetString(this Encoding encoding, byte[] bytes, int index, int count, out string result)
        {
            result = null;
            Decoder decoder = encoding.GetDecoder();
            decoder.Fallback = DecoderFallback.ExceptionFallback;
            try
            {
                int charCount = decoder.GetCharCount(bytes, index, count);
                char[] chars = new char[charCount];
                decoder.GetChars(bytes, index, count, chars, 0);
                result = new string(chars);
                return true;
            }
            catch (DecoderFallbackException)
            {
                return false;
            }
        }
    }
}
