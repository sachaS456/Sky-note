using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sky_updater;
using System.Threading;

namespace Sky_note
{
    public static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Thread thread = new Thread(new ThreadStart(CheckUpdate));
            thread.Priority = ThreadPriority.Highest;
            thread.Start();

            Application.Run(new FormPrincipal());
        }

        private static void CheckUpdate()
        {
            Update.CheckUpdate("Sky note", Application.ProductVersion);
        }
    }
}
