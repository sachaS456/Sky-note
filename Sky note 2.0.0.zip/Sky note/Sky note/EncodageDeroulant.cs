﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sky_note
{
    internal delegate void EventEncodingHandler(ref Encoding e);

    internal partial class EncodageDeroulant : UserControl
    {
        internal EventEncodingHandler EventEncoding = null;

        internal EncodageDeroulant()
        {
            InitializeComponent();
        }

        protected virtual void EventEncodingMethode(Encoding e)
        {
            if (EventEncoding != null)
            {
                EventEncoding(ref e);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // utf8
            EventEncodingMethode(Encoding.UTF8);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // BigEndianUnicode
            EventEncodingMethode(Encoding.BigEndianUnicode);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // unicode
            EventEncodingMethode(Encoding.Unicode);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // utf32
            EventEncodingMethode(Encoding.UTF32);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // ascii
            EventEncodingMethode(Encoding.ASCII);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // Latin1
            EventEncodingMethode(Encoding.Latin1);
        }
    }
}
